var total=0;
var players={};
var winCount=0;
function startGame(){
    if(parseInt(document.getElementById('grid').value)>=2 && parseInt(document.getElementById('players').value)>0){
        // alert('Game started');
        total=parseInt(document.getElementById('grid').value)*parseInt(document.getElementById('grid').value);
        players.length=parseInt(document.getElementById('players').value);
        for(var i=0; i<players.length;i++){
            createPlayerDiv(i);
            var span=document.createElement('span')
            var br=document.createElement('br');
            span.innerHTML=`${i+1}`
            document.getElementById('playersNum').appendChild(br);
            document.getElementById('playersNum').appendChild(span);
            document.getElementById('playersNum').appendChild(br);
            players[i]=1;
        }
        
        for(var l=0;l<100000;l++){
            for(var j=0;j<players.length;j++){
            if(players[j]==total){
                document.getElementById('winner').innerHTML=` Winner is Player${j+1}`

                console.log(`Player${j+1} is winner`);
                winCount=1;
                break;
            }
        }
            if(winCount==1){
                break;
            }
                for(var k=0;k<players.length;k++){
                    var randNum=(Math.floor(Math.random()*6));
                    console.log(randNum);
                    document.getElementById('dies').childNodes[k+1].childNodes[1].innerHTML=`${document.getElementById('dies').childNodes[k+1].childNodes[1].innerHTML},${randNum}`
                    if(players[k]+randNum<=total){
                        players[k]+=randNum;
                    }

                
            }
        }

    }
    
}
function createPlayerDiv(i){
    var div=document.createElement('div')
    var span=document.createElement('span')
    span.innerHTML=`Player${i+1}----`
    var span2=document.createElement('span');
    div.appendChild(span);
    div.appendChild(span2);
    document.getElementById('dies').appendChild(div);


}