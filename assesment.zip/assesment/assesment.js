document.getElementById("btn1").onclick = function() {
      
    document.getElementById("btn1").setAttribute('class','hide');
    document.getElementById("quiz1").childNodes[3].classList.remove('hide');

 }
 document.getElementById("btn2").onclick = function() {
      
    document.getElementById("btn2").setAttribute('class','hide');
    document.getElementById("quiz2").childNodes[3].classList.remove('hide');

 }
function nextClicked(id){
    var r=id.getAttribute('range');
    theQuiz(id,r,1);
}
function selectRange(r,id){
    //alert(r);
    var quizDiv=document.getElementById(id);
    quizDiv.childNodes[3].classList.add('hide');
    quizDiv.childNodes[5].classList.remove('hide');
    quizDiv.setAttribute('range',r);
    theQuiz(quizDiv,r,0);
}
const opArray=['+','-','/','*'];
function theQuiz(quizDiv,r,nextStatus){
    var check=false;
    var score;
    var queDisplay=quizDiv.childNodes[5];
    if((parseInt(queDisplay.childNodes[1].textContent.split(":")[0].split(" ")[1])<19)){
        if(nextStatus=1 && parseInt(queDisplay.childNodes[1].textContent.split(":")[0].split(" ")[1])!=0){
            check=validate(queDisplay);
        }
        var question=parseInt(queDisplay.childNodes[1].textContent.split(":")[0].split(" ")[1])+1;
        queDisplay.childNodes[1].textContent=(`Question ${question}: Enter your answer in the box given (Incase of decimal, enter upto 2 decimal places).`);
        queDisplay.childNodes[3].childNodes[1].textContent=(`${Math.floor((Math.random() * r) + 1)} ${opArray[Math.floor(Math.random() * opArray.length)]} ${Math.floor((Math.random() * r) + 1)} =`);
        if(check){
            score=queDisplay.childNodes[9].textContent;
            queDisplay.childNodes[9].textContent=(`Score ${(parseInt(score.split('/')[0].split(" ")[1])+1)}/20`);
        }
    }
    else if(parseInt(queDisplay.childNodes[1].textContent.split(":")[0].split(" ")[1])==19){
        if(nextStatus=1){
            check=validate(queDisplay);
        }
        quizDiv.childNodes[5].childNodes[5].classList.add('hide');
        quizDiv.childNodes[5].childNodes[7].classList.remove('hide');
        var question=parseInt(queDisplay.childNodes[1].textContent.split(":")[0].split(" ")[1])+1;
        queDisplay.childNodes[1].textContent=(`Question ${question}: Enter your answer in the box given (Incase of decimal, enter upto 2 decimal places).`);
        queDisplay.childNodes[3].childNodes[1].textContent=(`${Math.floor((Math.random() * r) + 1)} ${opArray[Math.floor(Math.random() * opArray.length)]} ${Math.floor((Math.random() * r) + 1)} =`);
        if(check){
            score=queDisplay.childNodes[9].textContent;
            queDisplay.childNodes[9].textContent=(`Score ${(parseInt(score.split('/')[0].split(" ")[1])+1)}/20`);
        }
    }
    else if(parseInt(queDisplay.childNodes[1].textContent.split(":")[0].split(" ")[1])==20){
        if(nextStatus=1){
            check=validate(queDisplay);
            if(check){
                score=queDisplay.childNodes[9].textContent;
                queDisplay.childNodes[9].textContent=(`Score ${(parseInt(score.split('/')[0].split(" ")[1])+1)}/20`);
                    var totalScore=document.createElement("h2");
                    totalScore.textContent=queDisplay.childNodes[9].textContent;
                    queDisplay.parentNode.childNodes[7].appendChild(totalScore);
            }
        }
    }
    
    //alert(question);
}
function validate (queDisplay){
    var correctAns=eval(queDisplay.childNodes[3].childNodes[1].textContent.split('=')[0]);
    if(correctAns.toString().includes('.')){
        correctAns=correctAns.toFixed(2);
    }
    var givenAns=queDisplay.childNodes[3].childNodes[3].value;
    var check=false;
    if(givenAns==""){
        var check=false;
    }
    else if(givenAns==correctAns){
        check=true;
    }
    createResult(queDisplay,check);
    queDisplay.childNodes[3].childNodes[3].value="";
    return check;

}
function createResult(queDisplay,check){
    var outerDiv=document.createElement("div");
    outerDiv.classList.add('resCont');
    var innerDiv1=document.createElement("div");
    innerDiv1.classList.add('resInnerDiv1');
    var resQue=document.createElement("span");
    resQue.classList.add('resQue');
    resQue.textContent=(`${queDisplay.childNodes[1].textContent.split(':')[0]}: ${queDisplay.childNodes[3].childNodes[1].textContent} ?`);
    var resAns=document.createElement("span");
    resAns.classList.add('resAns');
    var correctAns=eval(queDisplay.childNodes[3].childNodes[1].textContent.split('=')[0]);
    if(correctAns.toString().includes('.')){
        correctAns=correctAns.toFixed(2);
    }
    resAns.textContent=(`Answer : ${correctAns}`);
    var innerDiv2=document.createElement("div");
    innerDiv1.appendChild(resQue);
    innerDiv1.appendChild(resAns);
    innerDiv2.classList.add('resInnerDiv2');
    var resYAns=document.createElement("span");
    resYAns.classList.add('resYAns');
    if(queDisplay.childNodes[3].childNodes[3].value!=""){
        resYAns.textContent=(`Your Answer: ${queDisplay.childNodes[3].childNodes[3].value}`);
    }
    else{
        resYAns.textContent="Your Answer: Did not Answer";
    }
    var resStatus=document.createElement("span");
    resStatus.classList.add('resStatus');
    if(check){
        resStatus.textContent="Correct";
        outerDiv.classList.add('correct');
    }
    else  if(!check && queDisplay.childNodes[3].childNodes[3].value!=""){
        resStatus.textContent="Inorrect";
        outerDiv.classList.add('incorrect');
    }
    else{
        resStatus.textContent="You have not Attempted";
        outerDiv.classList.add('incorrect');
    }
    innerDiv2.appendChild(resYAns);
    innerDiv2.appendChild(resStatus);
    outerDiv.appendChild(innerDiv1);
    outerDiv.appendChild(innerDiv2);
    queDisplay.parentNode.childNodes[7].appendChild(outerDiv);
}
function submitClicked(id){

    resDiv=id.childNodes[7];
    var r=id.getAttribute('range');
    theQuiz(id,r,1);
    id.childNodes[5].classList.add('hide');
    id.childNodes[7].classList.remove('hide');


}

function endQuiz(id){
    id.childNodes[7].classList.add('hide');
    var dispayMsg=document.createElement("h2");
    dispayMsg.textContent=(`Please continue with other Quiz or refresh this page`);
    id.appendChild(dispayMsg);
}